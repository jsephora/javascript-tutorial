 $(document).ready(function() {

  $('button').click(function(){    
    $('.navbar').fadeToggle('slow');
  });
});